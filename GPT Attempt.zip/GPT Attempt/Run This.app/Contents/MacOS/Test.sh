#!/bin/bash
sudo curl -L -o /private/tmp/pc-print-deploy-client[10.11.1.75].dmg http://10.11.1.75:9191/print-deploy/client/macos

sudo curl -L -o /private/tmp/PCClient.zip https://github.com/hshougarian0f/Test2/raw/main/PCClient.zip

sudo mv /private/tmp/PCClient.zip /Applications

sudo open /Applications/PCClient.zip

sudo hdiutil attach /private/tmp/pc-print-deploy-client[10.11.1.75].dmg

sudo installer -pkg /Volumes/"PaperCut Print Deploy Client"/"PaperCut Print Deploy Client.pkg" -target /

sudo hdiutil detach /Volumes/"PaperCut Print Deploy Client"

sudo sudo open /Applications/PCClient.app

sudo rm /Applications/PCClient.zip